# Broiler Backend (Spring Boot 3, Java 21)

## Run
1. Create MySQL database and user:
```sql
CREATE DATABASE broiler_db;
CREATE USER 'broiler_user'@'%' IDENTIFIED BY 'broiler_pass';
GRANT ALL PRIVILEGES ON broiler_db.* TO 'broiler_user'@'%';
FLUSH PRIVILEGES;
```
2. Edit `src/main/resources/application.yml` if needed.
3. Build & run:
```bash
mvn spring-boot:run
```
4. Swagger UI at `/swagger-ui/index.html`

## Auth
POST `/api/auth/login` with JSON `{ "username":"admin","password":"admin123" }` → JWT.
Use `Authorization: Bearer <token>` for subsequent calls.
