package com.example.broiler.repository;

import com.example.broiler.domain.VendorRateOffset;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.time.LocalDate;
import java.util.List;

public interface VendorRateOffsetRepository extends JpaRepository<VendorRateOffset, Long> {
    
    
    
    
    Optional<VendorRateOffset> findByVendorId(Long vendorId);
}
