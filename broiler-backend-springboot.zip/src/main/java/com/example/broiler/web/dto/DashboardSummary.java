package com.example.broiler.service.dto;

import java.util.List;

public class DashboardSummary {
    public static class TripSummary {
        public Long tripId;
        public String driverName;
        public String routeName;
        public double totalWeight;
        public double totalPayments;
    }
    public List<TripSummary> trips;
}
