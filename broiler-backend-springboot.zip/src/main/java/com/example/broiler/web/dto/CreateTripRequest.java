package com.example.broiler.web.dto;

import java.time.LocalDate;
import java.util.List;
import jakarta.validation.constraints.*;

public class CreateTripRequest {
    @NotNull
    private LocalDate tripDate;
    @NotNull
    private Long driverId;
    @NotBlank
    private String routeName;
    @NotEmpty
    private List<StopDto> stops;

    public static class StopDto {
        @NotNull
        private Long vendorId;
        @NotNull
        private Integer assignedUnits;
        @NotNull
        private Integer sequence;

        public Long getVendorId() { return vendorId; }
        public void setVendorId(Long vendorId) { this.vendorId = vendorId; }
        public Integer getAssignedUnits() { return assignedUnits; }
        public void setAssignedUnits(Integer assignedUnits) { this.assignedUnits = assignedUnits; }
        public Integer getSequence() { return sequence; }
        public void setSequence(Integer sequence) { this.sequence = sequence; }
    }

    public LocalDate getTripDate() { return tripDate; }
    public void setTripDate(LocalDate tripDate) { this.tripDate = tripDate; }
    public Long getDriverId() { return driverId; }
    public void setDriverId(Long driverId) { this.driverId = driverId; }
    public String getRouteName() { return routeName; }
    public void setRouteName(String routeName) { this.routeName = routeName; }
    public List<StopDto> getStops() { return stops; }
    public void setStops(List<StopDto> stops) { this.stops = stops; }
}
