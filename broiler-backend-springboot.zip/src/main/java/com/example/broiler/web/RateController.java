package com.example.broiler.web;

import com.example.broiler.service.RateService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rates")
public class RateController {

    private final RateService rateService;

    public RateController(RateService rateService){
        this.rateService = rateService;
    }

    @PostMapping("/base")
    public ResponseEntity<Void> setBase(@RequestParam Double rate){
        rateService.setBaseRate(rate);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/offset")
    public ResponseEntity<Void> setOffset(@RequestParam Long vendorId, @RequestParam Double offset){
        rateService.setVendorOffset(vendorId, offset);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/effective")
    public ResponseEntity<Double> effective(@RequestParam Long vendorId){
        return ResponseEntity.ok(rateService.getEffectiveRate(vendorId));
    }
}
