package com.example.broiler.web;

import com.example.broiler.service.DashboardService;
import com.example.broiler.service.dto.DashboardSummary;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService){
        this.dashboardService = dashboardService;
    }

    @GetMapping("/summary")
    public ResponseEntity<DashboardSummary> summary(){
        return ResponseEntity.ok(dashboardService.getDashboardSummary());
    }
}
