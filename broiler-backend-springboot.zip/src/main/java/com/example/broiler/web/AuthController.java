package com.example.broiler.web;

import com.example.broiler.domain.Admin;
import com.example.broiler.repository.AdminRepository;
import com.example.broiler.security.jwt.JwtUtils;
import com.example.broiler.web.dto.AuthDtos;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AdminRepository adminRepository;
    private final PasswordEncoder encoder;
    private final JwtUtils jwtUtils;

    public AuthController(AdminRepository adminRepository, PasswordEncoder encoder, JwtUtils jwtUtils){
        this.adminRepository = adminRepository;
        this.encoder = encoder;
        this.jwtUtils = jwtUtils;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Validated @RequestBody AuthDtos.LoginRequest req){
        Admin admin = adminRepository.findByUsername(req.getUsername()).orElse(null);
        if (admin == null || !encoder.matches(req.getPassword(), admin.getPassword())){
            return ResponseEntity.status(401).body("Invalid credentials");
        }
        String token = jwtUtils.generateJwtToken(admin.getUsername());
        return ResponseEntity.ok(new AuthDtos.JwtResponse(token));
    }
}
