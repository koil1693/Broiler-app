package com.example.broiler.web;

import com.example.broiler.domain.Vendor;
import com.example.broiler.repository.VendorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vendors")
public class VendorController {

    private final VendorRepository vendorRepository;

    public VendorController(VendorRepository vendorRepository){
        this.vendorRepository = vendorRepository;
    }

    @GetMapping
    public ResponseEntity<List<Vendor>> all(){
        return ResponseEntity.ok(vendorRepository.findAll());
    }

    @PostMapping
    public ResponseEntity<Vendor> create(@Validated @RequestBody Vendor v){
        return ResponseEntity.ok(vendorRepository.save(v));
    }
}
