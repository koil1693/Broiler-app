package com.example.broiler.web;

import com.example.broiler.domain.Trip;
import com.example.broiler.service.TripService;
import com.example.broiler.web.dto.CreateTripRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips")
public class TripController {

    private final TripService tripService;

    public TripController(TripService tripService) {
        this.tripService = tripService;
    }

    @PostMapping
    public ResponseEntity<Trip> createTrip(@Validated @RequestBody CreateTripRequest dto){
        return ResponseEntity.ok(tripService.createTrip(dto));
    }

    @GetMapping("/today")
    public ResponseEntity<List<Trip>> getTodaysTrips(){
        return ResponseEntity.ok(tripService.getTodaysTrips());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Trip> getTripDetails(@PathVariable Long id){
        return ResponseEntity.ok(tripService.getTripDetails(id));
    }

    @PutMapping("/{id}/close")
    public ResponseEntity<Trip> closeTrip(@PathVariable Long id){
        return ResponseEntity.ok(tripService.closeTrip(id));
    }
}
