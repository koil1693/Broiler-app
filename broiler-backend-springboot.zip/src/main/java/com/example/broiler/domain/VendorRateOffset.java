package com.example.broiler.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class VendorRateOffset {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double offsetValue;

    @OneToOne
    @JoinColumn(name = "vendor_id", unique = true)
    private Vendor vendor;
}
