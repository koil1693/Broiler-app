package com.example.broiler.domain;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Trip {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate tripDate;

    @Column(nullable = false)
    private String status; // OPEN, CLOSED

    @ManyToOne(optional = false)
    private Driver driver;

    private String routeName;
}
