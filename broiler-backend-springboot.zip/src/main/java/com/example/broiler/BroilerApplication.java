package com.example.broiler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BroilerApplication {
    public static void main(String[] args) {
        SpringApplication.run(BroilerApplication.class, args);
    }
}
