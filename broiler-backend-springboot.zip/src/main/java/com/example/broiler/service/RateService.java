package com.example.broiler.service;

import com.example.broiler.domain.RateSettings;
import com.example.broiler.domain.VendorRateOffset;
import com.example.broiler.repository.RateSettingsRepository;
import com.example.broiler.repository.VendorRateOffsetRepository;
import com.example.broiler.repository.VendorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RateService {

    private final RateSettingsRepository rateSettingsRepository;
    private final VendorRateOffsetRepository vendorRateOffsetRepository;
    private final VendorRepository vendorRepository;

    public RateService(RateSettingsRepository rateSettingsRepository, VendorRateOffsetRepository vendorRateOffsetRepository, VendorRepository vendorRepository) {
        this.rateSettingsRepository = rateSettingsRepository;
        this.vendorRateOffsetRepository = vendorRateOffsetRepository;
        this.vendorRepository = vendorRepository;
    }

    @Transactional
    public void setBaseRate(Double rate){
        RateSettings base = rateSettingsRepository.findBySettingKey("BASE_RATE").orElseGet(() -> {
            RateSettings r = new RateSettings();
            r.setSettingKey("BASE_RATE");
            r.setSettingValue("0");
            return r;
        });
        base.setSettingValue(String.valueOf(rate));
        rateSettingsRepository.save(base);
    }

    @Transactional
    public void setVendorOffset(Long vendorId, Double offset){
        var vendor = vendorRepository.findById(vendorId).orElseThrow();
        VendorRateOffset vro = vendorRateOffsetRepository.findByVendorId(vendorId).orElseGet(() -> {
            VendorRateOffset v = new VendorRateOffset();
            v.setVendor(vendor);
            v.setOffsetValue(0d);
            return v;
        });
        vro.setOffsetValue(offset);
        vendorRateOffsetRepository.save(vro);
    }

    public double getEffectiveRate(Long vendorId){
        double base = rateSettingsRepository.findBySettingKey("BASE_RATE").map(r -> Double.parseDouble(r.getSettingValue())).orElse(0d);
        double offset = vendorRateOffsetRepository.findByVendorId(vendorId).map(VendorRateOffset::getOffsetValue).orElse(0d);
        return base + offset;
    }
}
