package com.example.broiler.service;

import com.example.broiler.domain.Trip;
import com.example.broiler.service.dto.DashboardSummary;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DashboardService {

    private final TripService tripService;

    public DashboardService(TripService tripService){
        this.tripService = tripService;
    }

    public DashboardSummary getDashboardSummary(){
        DashboardSummary summary = new DashboardSummary();
        List<DashboardSummary.TripSummary> list = new ArrayList<>();
        for (Trip t : tripService.getTodaysTrips()){
            DashboardSummary.TripSummary ts = new DashboardSummary.TripSummary();
            ts.tripId = t.getId();
            ts.driverName = t.getDriver().getName();
            ts.routeName = t.getRouteName();
            ts.totalWeight = tripService.totalWeightForTrip(t.getId());
            ts.totalPayments = tripService.totalPaymentsForTrip(t.getId());
            list.add(ts);
        }
        summary.trips = list;
        return summary;
    }
}
