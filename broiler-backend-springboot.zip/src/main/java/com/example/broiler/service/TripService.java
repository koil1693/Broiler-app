package com.example.broiler.service;

import com.example.broiler.domain.*;
import com.example.broiler.repository.*;
import com.example.broiler.web.dto.CreateTripRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TripService {

    private final TripRepository tripRepository;
    private final TripStopRepository tripStopRepository;
    private final DriverRepository driverRepository;
    private final VendorRepository vendorRepository;
    private final DeliveryLineRepository deliveryLineRepository;
    private final PaymentRepository paymentRepository;

    public TripService(TripRepository tripRepository, TripStopRepository tripStopRepository, DriverRepository driverRepository, VendorRepository vendorRepository, DeliveryLineRepository deliveryLineRepository, PaymentRepository paymentRepository) {
        this.tripRepository = tripRepository;
        this.tripStopRepository = tripStopRepository;
        this.driverRepository = driverRepository;
        this.vendorRepository = vendorRepository;
        this.deliveryLineRepository = deliveryLineRepository;
        this.paymentRepository = paymentRepository;
    }

    @Transactional
    public Trip createTrip(CreateTripRequest dto) {
        Driver driver = driverRepository.findById(dto.getDriverId()).orElseThrow();
        Trip trip = Trip.builder()
                .tripDate(dto.getTripDate())
                .status("OPEN")
                .driver(driver)
                .routeName(dto.getRouteName())
                .build();
        trip = tripRepository.save(trip);

        for (CreateTripRequest.StopDto s : dto.getStops()) {
            Vendor v = vendorRepository.findById(s.getVendorId()).orElseThrow();
            TripStop stop = TripStop.builder()
                    .trip(trip)
                    .vendor(v)
                    .assignedUnits(s.getAssignedUnits())
                    .sequence(s.getSequence())
                    .build();
            tripStopRepository.save(stop);
        }
        return trip;
    }

    public List<Trip> getTodaysTrips() {
        return tripRepository.findByTripDate(LocalDate.now());
    }

    public Trip getTripDetails(Long tripId) {
        // JPA will lazy-load relations where needed; controllers can aggregate via repos.
        return tripRepository.findById(tripId).orElseThrow();
    }

    @Transactional
    public Trip closeTrip(Long tripId) {
        Trip t = tripRepository.findById(tripId).orElseThrow();
        t.setStatus("CLOSED");
        return tripRepository.save(t);
    }

    public double totalWeightForTrip(Long tripId){
        List<TripStop> stops = tripStopRepository.findAll().stream().filter(s -> s.getTrip().getId().equals(tripId)).collect(Collectors.toList());
        double sum = 0d;
        for (TripStop s : stops){
            List<DeliveryLine> lines = deliveryLineRepository.findAll().stream().filter(l -> l.getStop().getId().equals(s.getId())).collect(Collectors.toList());
            sum += lines.stream().mapToDouble(l -> l.getWeight() != null ? l.getWeight() : 0d).sum();
        }
        return sum;
    }

    public double totalPaymentsForTrip(Long tripId){
        List<TripStop> stops = tripStopRepository.findAll().stream().filter(s -> s.getTrip().getId().equals(tripId)).collect(Collectors.toList());
        double sum = 0d;
        for (TripStop s : stops){
            List<Payment> pmts = paymentRepository.findAll().stream().filter(p -> p.getStop().getId().equals(s.getId())).collect(Collectors.toList());
            sum += pmts.stream().mapToDouble(p -> p.getAmount() != null ? p.getAmount() : 0d).sum();
        }
        return sum;
    }
}
