INSERT INTO admin (username, password) VALUES
('admin', '$2a$10$9mS3y3m9e1p0tHf9S6kqUuX0c0F3JvU0S3vKq1q7f8j8wC2G3bY1.'); -- password: admin123

INSERT INTO driver (name, username, password) VALUES
('Ravi Kumar','ravi','{bcrypt}$2a$10$Q7aqX0r7H4I3Y0p8fESeRu0vQmUbn9iB6mY7h5ZsE9b1T6YVYvDfi'); -- password not used

INSERT INTO vendor (name, contact_person, phone_number, address) VALUES
('Fresh Farms','Meena','9876543210','Chennai'),
('Green Poultry','Suresh','9123456780','Bengaluru');

INSERT INTO rate_settings (setting_key, setting_value) VALUES
('BASE_RATE','120.0');
