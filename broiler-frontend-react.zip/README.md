# Broiler Admin Frontend (React 18 + Vite + Tailwind)

## Setup
```bash
npm i
npm run dev
```
Create `.env` with:
```
VITE_API_BASE=http://localhost:8080
```
Login with admin/admin123.
