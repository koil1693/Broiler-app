import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import LoginPage from '../pages/LoginPage'
import DashboardPage from '../pages/DashboardPage'
import TripDetailsPage from '../pages/TripDetailsPage'
import TripCreationPage from '../pages/TripCreationPage'
import RateManagementPage from '../pages/RateManagementPage'

function PrivateRoute({ children }){
  const token = localStorage.getItem('token')
  return token ? children : <Navigate to="/login" />
}

export default function AppRoutes(){
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/" element={<Navigate to="/dashboard" />} />
      <Route path="/dashboard" element={<PrivateRoute><DashboardPage /></PrivateRoute>} />
      <Route path="/trips/new" element={<PrivateRoute><TripCreationPage /></PrivateRoute>} />
      <Route path="/trips/:id" element={<PrivateRoute><TripDetailsPage /></PrivateRoute>} />
      <Route path="/rates" element={<PrivateRoute><RateManagementPage /></PrivateRoute>} />
    </Routes>
  )
}
