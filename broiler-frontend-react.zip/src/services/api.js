const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8080';

function getToken(){
  return localStorage.getItem('token');
}

async function apiFetch(path, options = {}){
  const headers = options.headers || {};
  if (!headers['Content-Type'] && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  if (res.status === 401) {
    localStorage.removeItem('token');
    window.location.href = '/login';
    return;
  }
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || 'Request failed');
  }
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) return res.json();
  return res.text();
}

export const AuthApi = {
  async login(username, password){
    const res = await apiFetch('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });
    localStorage.setItem('token', res.token);
    return res;
  }
}

export const TripApi = {
  createTrip: (dto) => apiFetch('/api/trips', { method: 'POST', body: JSON.stringify(dto) }),
  todays: () => apiFetch('/api/trips/today'),
  details: (id) => apiFetch(`/api/trips/${id}`),
  close: (id) => apiFetch(`/api/trips/${id}/close`, { method: 'PUT' })
}

export const RateApi = {
  setBase: (rate) => apiFetch(`/api/rates/base?rate=${encodeURIComponent(rate)}`, { method: 'POST' }),
  setOffset: (vendorId, offset) => apiFetch(`/api/rates/offset?vendorId=${vendorId}&offset=${offset}`, { method: 'POST' }),
  effective: (vendorId) => apiFetch(`/api/rates/effective?vendorId=${vendorId}`)
}

export const VendorApi = {
  list: () => apiFetch('/api/vendors'),
  create: (vendor) => apiFetch('/api/vendors', { method: 'POST', body: JSON.stringify(vendor) })
}
