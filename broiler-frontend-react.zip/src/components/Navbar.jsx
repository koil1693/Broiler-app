import React from 'react'
import { Link, useLocation } from 'react-router-dom'

export default function Navbar(){
  const loc = useLocation()
  const active = (path) => loc.pathname.startsWith(path) ? 'text-blue-600' : 'text-gray-600'
  return (
    <div className="bg-white shadow">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="font-semibold text-lg">Broiler Admin</Link>
        <div className="space-x-6">
          <Link to="/dashboard" className={active('/dashboard')}>Dashboard</Link>
          <Link to="/trips/new" className={active('/trips')}>Create Trip</Link>
          <Link to="/rates" className={active('/rates')}>Rates</Link>
        </div>
        <button className="text-sm text-red-600" onClick={() => { localStorage.removeItem('token'); window.location.href='/login';}}>Logout</button>
      </div>
    </div>
  )
}
