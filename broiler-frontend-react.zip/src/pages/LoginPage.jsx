import React, { useState } from 'react'
import { AuthApi } from '../services/api'

export default function LoginPage(){
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('admin123')
  const [error, setError] = useState('')

  const onSubmit = async (e) => {
    e.preventDefault()
    try {
      await AuthApi.login(username, password)
      window.location.href = '/dashboard'
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={onSubmit} className="bg-white p-8 rounded-xl shadow max-w-sm w-full">
        <h1 className="text-xl font-semibold mb-6">Admin Login</h1>
        {error && <div className="text-red-600 text-sm mb-2">{error}</div>}
        <label className="block text-sm">Username</label>
        <input className="w-full border rounded p-2 mb-4" value={username} onChange={e=>setUsername(e.target.value)} />
        <label className="block text-sm">Password</label>
        <input type="password" className="w-full border rounded p-2 mb-6" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="w-full bg-blue-600 text-white rounded p-2">Login</button>
      </form>
    </div>
  )
}
