import React, { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { TripApi } from '../services/api'
import { Link } from 'react-router-dom'

export default function DashboardPage(){
  const [trips, setTrips] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(()=>{
    (async () => {
      try{
        const res = await TripApi.todays()
        setTrips(res)
      }catch(e){ setError(e.message) } finally{ setLoading(false) }
    })()
  }, [])

  return (
    <div>
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-6">
        <h1 className="text-2xl font-semibold mb-4">Today's Trips</h1>
        {loading && <div>Loading...</div>}
        {error && <div className="text-red-600">{error}</div>}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {trips.map(t => (
            <Link key={t.id} to={`/trips/${t.id}`} className="bg-white rounded-xl shadow p-4 hover:shadow-md transition">
              <div className="font-medium">{t.routeName || 'Route'}</div>
              <div className="text-sm text-gray-600">Driver: {t.driver?.name}</div>
              <div className="text-sm text-gray-600">Status: {t.status}</div>
              <div className="mt-2 text-xs text-gray-500">Tap to view details</div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
