import React, { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { TripApi } from '../services/api'
import { useParams } from 'react-router-dom'

export default function TripDetailsPage(){
  const { id } = useParams()
  const [trip, setTrip] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(()=>{
    (async()=>{
      try{
        const t = await TripApi.details(id)
        setTrip(t)
      }catch(e){ setError(e.message) } finally { setLoading(false) }
    })()
  }, [id])

  if (loading) return <div><Navbar /><div className='p-6'>Loading...</div></div>
  if (error) return <div><Navbar /><div className='p-6 text-red-600'>{error}</div></div>
  if (!trip) return <div><Navbar /><div className='p-6'>Not Found</div></div>

  return (
    <div>
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="bg-white rounded-xl shadow p-4 mb-4">
          <div className="text-lg font-semibold">Trip #{trip.id} — {trip.routeName}</div>
          <div className="text-sm text-gray-600">Driver: {trip.driver?.name}</div>
          <div className="text-sm text-gray-600">Date: {trip.tripDate}</div>
          <div className="text-sm text-gray-600">Status: {trip.status}</div>
        </div>

        <div className="bg-white rounded-xl shadow p-4">
          <h2 className="font-medium mb-2">Stops</h2>
          <p className="text-xs text-gray-500 mb-3">DeliveryLines & Payments are collapsed in this starter. Extend by adding dedicated endpoints for lines and payments.</p>
          <div className="space-y-2">
            {(trip.stops || []).length === 0 && <div className="text-sm text-gray-500">No stops yet.</div>}
            {/* In this starter, stops are not eagerly serialized; add a projection/DTO if needed. */}
          </div>
        </div>
      </div>
    </div>
  )
}
