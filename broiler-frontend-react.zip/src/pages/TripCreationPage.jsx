import React, { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { TripApi, VendorApi } from '../services/api'
import { useNavigate } from 'react-router-dom'

export default function TripCreationPage(){
  const [tripDate, setTripDate] = useState(new Date().toISOString().slice(0,10))
  const [routeName, setRouteName] = useState('Route A')
  const [driverId, setDriverId] = useState(1)
  const [vendors, setVendors] = useState([])
  const [stops, setStops] = useState([{ vendorId: 1, assignedUnits: 100, sequence: 1 }])
  const [error, setError] = useState('')
  const navigate = useNavigate()

  useEffect(()=>{
    (async()=>{
      try{
        const list = await VendorApi.list()
        setVendors(list)
        if (list.length) {
          setStops([{ vendorId: list[0].id, assignedUnits: 100, sequence: 1 }])
        }
      }catch(e){ setError(e.message) }
    })()
  }, [])

  const addStop = () => setStops(s => [...s, { vendorId: vendors[0]?.id || 1, assignedUnits: 0, sequence: s.length+1 }])
  const updateStop = (idx, key, value) => {
    setStops(s => s.map((st, i) => i === idx ? { ...st, [key]: value } : st))
  }
  const removeStop = (idx) => setStops(s => s.filter((_, i) => i !== idx))

  const onSubmit = async (e) => {
    e.preventDefault()
    try{
      const dto = { tripDate, routeName, driverId: Number(driverId), stops }
      const trip = await TripApi.createTrip(dto)
      navigate(`/trips/${trip.id}`)
    }catch(e){ setError(e.message) }
  }

  return (
    <div>
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-6">
        <h1 className="text-xl font-semibold mb-4">Create Trip</h1>
        {error && <div className="text-red-600 mb-2">{error}</div>}
        <form onSubmit={onSubmit} className="bg-white rounded-xl shadow p-4 space-y-4">
          <div>
            <label className="block text-sm">Trip Date</label>
            <input type="date" className="border rounded p-2" value={tripDate} onChange={e=>setTripDate(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm">Route Name</label>
            <input className="border rounded p-2" value={routeName} onChange={e=>setRouteName(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm">Driver (ID)</label>
            <input className="border rounded p-2" value={driverId} onChange={e=>setDriverId(e.target.value)} />
            <p className="text-xs text-gray-500">For the starter, enter Driver ID (seeded driver has ID=1). Extend with a dropdown.</p>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Stops</label>
              <button type="button" className="text-blue-600 text-sm" onClick={addStop}>+ Add Stop</button>
            </div>
            <div className="space-y-3 mt-2">
              {stops.map((st, idx)=>(
                <div key={idx} className="border rounded p-3 grid grid-cols-1 md:grid-cols-4 gap-2 items-end">
                  <div>
                    <label className="block text-xs">Vendor</label>
                    <select className="border rounded p-2 w-full" value={st.vendorId} onChange={e=>updateStop(idx,'vendorId', Number(e.target.value))}>
                      {vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs">Units</label>
                    <input type="number" className="border rounded p-2 w-full" value={st.assignedUnits} onChange={e=>updateStop(idx,'assignedUnits', Number(e.target.value))}/>
                  </div>
                  <div>
                    <label className="block text-xs">Sequence</label>
                    <input type="number" className="border rounded p-2 w-full" value={st.sequence} onChange={e=>updateStop(idx,'sequence', Number(e.target.value))}/>
                  </div>
                  <div className="text-right">
                    <button type="button" className="text-red-600 text-sm" onClick={()=>removeStop(idx)}>Remove</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button className="bg-blue-600 text-white rounded px-4 py-2">Create Trip</button>
        </form>
      </div>
    </div>
  )
}
