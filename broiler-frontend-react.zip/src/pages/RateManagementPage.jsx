import React, { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { RateApi, VendorApi } from '../services/api'

export default function RateManagementPage(){
  const [baseRate, setBaseRate] = useState(0)
  const [vendors, setVendors] = useState([])
  const [msg, setMsg] = useState('')

  useEffect(()=>{
    (async()=>{
      const list = await VendorApi.list()
      setVendors(list)
    })()
  }, [])

  const saveBase = async () => {
    await RateApi.setBase(baseRate)
    setMsg('Base rate saved.')
    setTimeout(()=>setMsg(''), 1500)
  }

  const saveOffset = async (vendorId, offset) => {
    await RateApi.setOffset(vendorId, offset)
    setMsg('Offset saved.')
    setTimeout(()=>setMsg(''), 1500)
  }

  return (
    <div>
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-4">
        <h1 className="text-xl font-semibold">Rate Management</h1>
        <div className="bg-white rounded-xl shadow p-4">
          <label className="block text-sm mb-1">Daily Base Rate</label>
          <div className="flex gap-2">
            <input type="number" className="border rounded p-2" value={baseRate} onChange={e=>setBaseRate(Number(e.target.value))}/>
            <button className="bg-blue-600 text-white rounded px-4" onClick={saveBase}>Save</button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow p-4">
          <div className="font-medium mb-2">Vendor Offsets</div>
          <div className="space-y-3">
            {vendors.map(v => (
              <div key={v.id} className="flex items-center gap-3">
                <div className="w-64">{v.name}</div>
                <input type="number" className="border rounded p-2" placeholder="Offset" onBlur={(e)=>saveOffset(v.id, Number(e.target.value))} />
              </div>
            ))}
          </div>
        </div>
        {msg && <div className="text-green-700 text-sm">{msg}</div>}
      </div>
    </div>
  )
}
